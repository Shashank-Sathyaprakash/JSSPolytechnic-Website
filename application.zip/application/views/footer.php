<!--FOOTER START-->
<!--NEWS LETTERS START-->
<div class="edu2_ft_topbar_wrap">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="edu2_ft_topbar_des">
          <h5>Join Our JSS Family 
          </h5>
        </div>
      </div>
      <div class="col-md-6">
        <div class="edu2_ft_topbar_des">
          <form>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!--NEWS LETTERS END-->
<footer>
  <!--EDU2 FOOTER CONTANT WRAP START-->
  <div class="container">
    <div class="row">
      <div class="widget_thumb">
        <img src="<?php echo base_url(); ?>assets/images/logo/10.png" alt="" />
      </div>
      <!--EDU2 FOOTER CONTANT DES START-->
      <div class="col-md-3">
        <div class="widget widget-links">
          <h5>Information
          </h5>
          <ul>
            <li>
              <a href="aboutus/JSSVP">About us
              </a>
            </li>
            <li>
              <a href="#">News & Events
              </a>
            </li>
            <li>
              <a href="#">Gallery
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!--EDU2 FOOTER CONTANT DES END-->
      <!--EDU2 FOOTER CONTANT DES START-->
      <div class="col-md-3">
        <div class="widget widget-links">
          <h5>Student Help
          </h5>
          <ul>
            <li>
              <a href="#">My Info
              </a>
            </li>
            <li>
              <a href="#">My Questions
              </a>
            </li>
            <li>
              <a href="#">Serch Courses
              </a>
            </li>
            <li>
              <a href="#">Latest Informations
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!--EDU2 FOOTER CONTANT DES START-->
      <div class="col-md-3">
        <div class="widget widget-contact">
          <h5>Contact
          </h5>
          <ul>
            <li>SJCE Campus, Manasa Gangothri, Mysuru, Karnataka 570006
            </li>
            <li>Phone : 
              <a href="#"> 0821 254 8318
              </a>
            </li>
            <li>Email : 
              <a href="#"> Info@info.com
              </a>
            </li>
          </ul>
        </div>
      </div>
      <!--EDU2 FOOTER CONTANT DES END-->
    </div>
  </div>
</footer>
<!--FOOTER END-->
<!--COPYRIGHTS START-->
<div class="edu2_copyright_wrap">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="edu2_ft_logo_wrap">
          <a href="#">
            <img src="<?php echo base_url(); ?>assets/images/.png" alt="" />
          </a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="copyright_des">
          <span>&copy; All Rights reserved. Powered By 
            <a href="#">THINKSONIC
            </a>
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
<!--COPYRIGHTS END-->
<!-- </div> -->
<!--KF KODE WRAPPER WRAP END-->
<!--Bootstrap core JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/jquery.js">
</script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js">
</script>
<!--Bx-Slider JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/jquery.bxslider.min.js">
</script>
<!--Owl Carousel JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js">
</script>
<!--Pretty Photo JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/jquery.prettyPhoto.js">
</script>
<!--Full Calender JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/moment.min.js">
</script>
<script src="<?php echo base_url(); ?>assets/js/fullcalendar.min.js">
</script>
<script src="<?php echo base_url(); ?>assets/js/jquery.downCount.js">
</script>
<!--Image Filterable JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/jquery-filterable.js">
</script>
<!--Accordian JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/jquery.accordion.js">
</script>
<!--Number Count (Waypoints) JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/waypoints-min.js">
</script>
<!--v ticker-->
<script src="<?php echo base_url(); ?>assets/js/jquery.vticker.min.js">
</script>
<!--select menu-->
<script src="<?php echo base_url(); ?>assets/js/jquery.selectric.min.js">
</script>
<!--Side Menu-->
<script src="<?php echo base_url(); ?>assets/js/jquery.sidr.min.js">
</script>
<!--Custom JavaScript-->
<script src="<?php echo base_url(); ?>assets/js/custom.js">
</script>
</body>
</html>