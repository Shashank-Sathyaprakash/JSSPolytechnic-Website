<!--previous years question papers-->
<?php include "header.php"; ?>

<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
<div class="row">
                           
                                <div class="card-box table-responsive">
                                   
                                    <h4 class="header-title m-t-0 m-b-30">Details</h4>

                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>SL.No</th>
                                                <th>Sem</th>
                                                <th>Subject</th>                                               
                                                <th>view</th>                                                                                                       
                                            </tr>
                                        </thead>


                                        <tbody>
                                        	  <?php 
                                            $i=0;
                                            foreach($question_paper as $row){
                                                $i++;
                                                ?>

                                            <tr>
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['semester'];?></td>
                                                <td><?php echo $row['subject'];?></td>
                                                <td><a href="<?php echo  base_url().'uploads/question_paper/'.$row['department'].'/'.$row['semester'].'/'.$row['file'];?>">view</a></td>
                                               
                                            </tr>
                                           
                                          <?php } ?>
                                          
                                           
                                          
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div><!-- end col -->
                        </div>
</div>
</div>

<?php include "footer.php"; ?>

