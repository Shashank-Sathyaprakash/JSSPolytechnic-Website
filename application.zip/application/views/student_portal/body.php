<?php include('header.php'); ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
<div class="col-md-9">

                        <div class="row">
    
                             <a href="<?php echo base_url();?>index.php/student_portal/calendar_of_events">
                               <div class="col-sm-4">
                                 <div class="panel panel-color panel-info">
                                    <div class="panel-heading ">
                                        <h3 class="panel-title">Calandar Of Events</h3>
                                    </div>
                                    <div class="panel-body fa fa-calendar" style="font-size:188px;color:#24b3de; ">
                                        
                                    </div>
                                </div>
                                </div>
                            </a>
                         <a href="<?php echo base_url();?>index.php/student_portal/time_table">
                             <div class=" col-sm-4 ">
                                <div class="panel panel-color panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Time Table</h3>
                                        </div>
                                        <div class="panel-body fa fa-clock-o" style="font-size:188px;color:#24b3de;">
                                        
                                    </div>
                                </div>
                            </div>
                        
                        </a>
    
                            <a href="<?php echo base_url();?>index.php/student_portal/syllabus">
                               <div class="col-md-4">
                                <div class="panel panel-color panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Syllabus</h3>
                                        </div>
                                        <div class="panel-body ">
                                        <div class="fa fa-graduation-cap" style="font-size:188px;color:#24b3de;">
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                        <div class="row">
    
                        <a href="<?php echo base_url();?>index.php/student_portal/notes">
                               <div class="col-md-4 col-sm-9">
                                <div class="panel panel-color panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Notes</h3>
                                        </div>
                                        <div class="panel-body fa fa-book" style="font-size:188px;color:#24b3de;">
                                        
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo base_url();?>index.php/student_portal/question_paper">    
                               <div class="col-md-4 col-sm-9">
                                <div class="panel panel-color panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Question Paper</h3>
                                        </div>
                                        <div class="panel-body fa fa-edit"  style="font-size:188px;color:#24b3de;">
                                        
                                    </div>
                                </div>
                            </div>
                           </a> 
                           <a href="<?php echo base_url();?>index.php/student_portal/cet">
                        <div class="col-md-4 col-sm-9">
                            <div class="panel panel-color panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">CET</h3>
                                        </div>
                                    <div class="panel-body fa fa-check-circle"  style="font-size:188px;color:#24b3de;">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
</div>

<div class="col-md-3 col-sm-9">
                            <!-- EDU2 SEARCH WRAP START -->
                            <div class="kf_edu2_search_wrap" style="margin-top:10px;">
                                <div class="kf_edu2_heading1">
                                    <h3>Latest News</h3><hr>
                                    <marquee direction="up" style="height: 490px;">
                                        This the blog displays that the <br>
                                     latest news or the events that are happening<br>
                                      in the college. but this is the dummy text <br>
                                      Pellentesque habitant morbi tristique senectus<br>
                                      et netus et malesuada fames ac turpis egestas.<br>
                                      Vestibulum tortor quam, feugiat vitae,<br>  </marquee>
                                </div>
                             </div>   
                            <!-- EDU2 SEARCH WRAP END -->
                            </div>
                        
<?php include('footer.php'); ?>

  <script type="text/javascript">
            $(document).ready(function() {
              $('.page-title').text('Options')
            }); 
  </script>                       
  