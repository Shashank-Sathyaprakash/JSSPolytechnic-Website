<?php include "header.php";>
<body>
<a href="<?php ['url'];?>" >click here</a>
</body>

<?php include "footer.php"; ?>