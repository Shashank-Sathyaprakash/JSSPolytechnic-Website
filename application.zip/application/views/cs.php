<?php include('header.php'); ?>
<body>
  <!--Banner Wrap Start-->
  <div class="kf_inr_banner">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <!--KF INR BANNER DES Wrap Start-->
          <div class="kf_inr_ban_des">
            <div class="inr_banner_heading">
              <h3>Computer Science & Engineering
              </h3>
            </div>
            <div class="kf_inr_breadcrumb">
              <ul>
                <li>
                  <a href="#">Home
                  </a>
                </li>
                <li>
                  <a href="#">Courses Details
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <!--KF INR BANNER DES Wrap End-->
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-12" style="padding: 50px;">    	
    <div class="col-md-7 col-sm-6">
      <div class="single_cos_item">
        <!-- COURSES DETAIL DES START -->
        <div class="kf_courses_detail_des">
          <div class="course_heading" style="padding-top:  1%;">
            <h3>About course
            </h3>
          </div>
          <p style="text-align:justify;">The Diploma Programme in Computer Science and Engineering shall consist of curricular component comprising courses in General Studies, Applied Sciences, 
            Basic Courses in Engineering Departmental Core, and, Specialised Courses in Computer Science and Engineering (Electives in emerging areas).
          <ul>
            <li>1.	Pursue a successful career in the field of Computer Science & Engineering or a related field utilizing his/her education and contribute to the profession as an excellent employee, or as an entrepreneur.
            </li>
            <li>2.	Be aware of the developments in the field of Computer Science & Engineering by continuously enhancing their knowledge informally.
            </li>
            <li>3.	Identify and engage in inquiry, develop new innovations and products.
            </li>
            <li>4.	Be able to work effectively in multidisciplinary and multicultural environments contributing positively to the needs of an individual & society at large.
            </li>
          </ul>
          </p>
      </div>
    </div>
  </div>
  <div class="col-md-5 col-sm-6">
    <!--widget courses  -->
    <div class="met-box vedio_tutoria" style="padding-top: 5%; ">
      <iframe width="100%" height="375px" src="https://youtu.be/L0WnWJV_SDc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>
      </iframe>
      <div class="inner_video">
      </div>							
    </div>
  </div>
  <section>
    <div class="col-md-6">
      <h3 >Our vision
      </h3>
      <div class="about_texts">
        <p> To build a strong learning environment in the field of
          <br>
          Computer Science and Engineering in technical education that responds
          <br>
          to the challenges of the century.
        </p>
      </div>	
    </div>
    <div class="col-md-6">
      <h3>Our Mission
      </h3>
      <div class="about_texts">
        <p> 
          To produce computer science diploma graduates who are trained in design, implementation, testing and maintenance of computational systems through competitive curriculum in collaboration with industry and other organizations.
          <br>
          Providing state of art facilities for enhancing skills in the field of computer science and engineering.
          <br>
          To encourage ethical values and leadership abilities in the minds of students so as to work towards the growth of the society.
          <br>
        </p>
      </div>	
    </div>
  </section>
  <!--KF EDUCATION STUDENT SLIDER WRAP START-->
  <section class="edu_student_wrap_bg">
    <div class="container">
      <div class="student_slider_wrap">
        <div class="row">
          <div class="col-md-6">
            <ul class="bxslider">
              <li>
                <!-- STUDENT SLIDER DES START-->
                <div class="student_slider_des">
                  <!-- HEADING 1 START-->
                  <div class="kf_edu2_heading1">
                    <h3>From HOD's Desk
                    </h3>
                  </div>
                  <!-- HEADING 1 END-->
                  <p>It is the best of department with experienced and highly qualified staff. Hands on experienced staff for importing practical training with sufficient and high end equipment. Maximum students to have got placement each year. Students have [passed with flying colours.
                  </p>
                  <div class="std_name_des">
                    <a href="#">Mrs.Shinu Koshy
                    </a>
                    <small>HOD,CS Department
                      <br>
                    </small>
                    <small>BE MTech
                      <br>
                      15 Year Experience
                    </small>
                  </div>
                </div>
                <!-- STUDENT SLIDER DES END-->
              </li>
            </ul>
          </div>
          <div class="col-md-6">
            <figure>
              <img src="<?php echo base_url();?>assets/images/cs_teachers/Mrs.png" height="450px" alt="principals image"
                   style="width: auto;padding: 9px  142px  14px;" />
            </figure>
          </div>
        </div>
        <!-- STUDENT SLIDER THUMB DES END-->
      </div>
    </div>
    </div>
  </div>
</section>
<!--KF EDUCATION STUDENT SLIDER WRAP END-->
<!-- FACULTY WRAP START-->
<section>
  <div class="container">
    <div class="row">
      <!-- HEADING 1 START-->
      <div class="col-md-12">
        <div class="kf_edu2_heading1">
          <h3>OUR TEACHERS
          </h3>
        </div>
      </div>
      <!-- HEADING 1 END-->
      <!-- FACULTY SLIDER WRAP START-->
      <div class="edu2_faculty_wrap">
        <div id="owl-demo-8" class="owl-carousel owl-theme">
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/LokeshaKR.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">Lokesha.K.R
                  </a>
                </h6>
                <strong>Teacher
                </strong>
                <p>BE MTech 
                </p>
                <p>11 Years Exp
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/SomyashreeHG.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">Sowmyashree.H.G
                  </a>
                </h6>
                <strong>Teacher
                </strong>
                <p>BE MTech
                </p> 
                <p>11 Years Exp.
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/SomaprabaS.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">Somaprabha.S
                  </a>
                </h6>
                <strong>Teacher
                </strong>
                <p>BE 
                </p>
                <p>9 Years Exp.
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/ShruthiS.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">Shruthi S
                  </a>
                </h6>
                <strong>Teacher
                </strong>
                <p>B.E MTech
                </p> 
                <p>7 Years Exp.
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/PrabhavathiC.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">Prabhavathi C
                  </a>
                </h6>
                <strong>Computer Operator
                </strong>
                <p>BSC. PGD BC
                </p>
                <p>18 Years
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/CJMahadevaswamy.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">C.J Mahadevaswamy 
                  </a>
                </h6>
                <strong>Mechanic
                </strong>
                <p>ITI
                </p>
                <p>16 Years
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
          <div class="item">
            <!-- FACULTY DES START-->
            <div class="edu2_faculty_des">
              <figure>
                <img src="<?php echo base_url();?>assets/images/cs_teachers/ChandruM.jpg" alt="" />
              </figure>
              <div class="edu2_faculty_des2">
                <h6>
                  <a href="#">Chandru M 
                  </a>
                </h6>
                <strong>Lab Helper
                </strong>
                <p>ITI PG DCA 
                </p>
                <p>9 Years
                </p>
              </div>
            </div>
            <!-- FACULTY DES END-->
          </div>
        </div>
        <!-- FACULTY DES END-->
      </div>
    </div>
  </div>
  <!-- FACULTY SLIDER WRAP END-->
  </div>
</div>
</section>
<!-- FACULTY WRAP START-->
<!--COUNTER SECTION START-->
<section class="edu2_counter_wrap">
  <div class="container">
    <!--EDU2 COUNTER DES START-->
    <div class="edu2_counter_des">
      <span>
        <i class="icon-group2">
        </i>
      </span>
      <h3 class="counter">160
      </h3>
      <h5>Number of students
      </h5>
    </div>
    <!--EDU2 COUNTER DES END-->
    <!--EDU2 COUNTER DES START-->
    <div class="edu2_counter_des">
      <span>
        <i class="icon-book236">
        </i>
      </span>
      <h3 class="counter">250
      </h3>
      <h5>Reference Books
      </h5>
    </div>
    <!--EDU2 COUNTER DES END-->
    <!--EDU2 COUNTER DES START-->
    <div class="edu2_counter_des">
      <span>
        <i class="icon-win5">
        </i>
      </span>
      <h3 class="counter">98
      </h3>
      <h5>Results
      </h5>
    </div>
    <!--EDU2 COUNTER DES END-->
    <!--EDU2 COUNTER DES START-->
    <div class="edu2_counter_des">
      <span>
        <i class=" icon-user255">
        </i>
      </span>
      <h3 class="counter">60
      </h3>
      <h5>Computers
      </h5>
    </div>
    <!--EDU2 COUNTER DES END-->
  </div>
</section>
<!--COUNTER SECTION END-->
<!--OUR TESTEMONIAL WRAP START-->
<section>
  <div class="container">
    <div class="row">
      <!-- HEADING 2 START-->
      <div class="col-md-12">
        <div class="kf_edu2_heading2">
          <h3>Our Testimonial
          </h3>
        </div>
      </div>
      <!-- HEADING 2 END-->
      <!-- TESTEMONIAL SLIDER WRAP START-->
      <div class="edu2_testemonial_slider_wrap">
        <div id="owl-demo-9">
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="./extra-images/testemonial.1.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="./extra-images/testemonial.2.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="./extra-images/testemonial.1.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="./extra-images/testemonial.2.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="./extra-images/testemonial.1.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="./extra-images/testemonial.2.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
        </div>
      </div>
      <!-- TESTEMONIAL SLIDER WRAP END-->
    </div>
  </div>
</section>
<!--OUR TESTEMONIAL WRAP END-->
</div>
<!-- HEADING 1 START-->
<!-- HEADING 1 END-->
<!--Content Wrap End-->
<?php include('footer.php'); ?>
</body>
</html>
