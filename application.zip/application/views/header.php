<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="image/png" href="<?php echo base_url();?>assets/images/logo/jsslogo.png" />
    <title>JSS POLYTECHNIC
    </title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Full Calender CSS -->
    <link href="<?php echo base_url();?>assets/css/fullcalendar.css" rel="stylesheet" />
    <!-- Owl Carousel CSS -->
    <link href="<?php echo base_url();?>assets/css/owl.carousel.css" rel="stylesheet" />
    <!-- Pretty Photo CSS -->
    <link href="<?php echo base_url();?>assets/css/prettyPhoto.css" rel="stylesheet" />
    <!-- Bx-Slider StyleSheet CSS -->
    <link href="<?php echo base_url();?>assets/css/jquery.bxslider.css" rel="stylesheet" /> 
    <!-- Font Awesome StyleSheet CSS -->
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>assets/svg/style.css" rel="stylesheet" />
    <!-- Widget CSS -->
    <link href="<?php echo base_url();?>assets/css/widget.css" rel="stylesheet" />
    <!-- Typography CSS -->
    <link href="<?php echo base_url();?>assets/css/typography.css" rel="stylesheet" />
    <!-- Shortcodes CSS -->
    <link href="<?php echo base_url();?>assets/css/shortcodes.css" rel="stylesheet" />
    <!-- Custom Main StyleSheet CSS -->
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" />
    <!-- News & Gallery -->
    <link href="<?php echo base_url();?>assets/css/news.css" rel="stylesheet" />
    <!-- Color CSS -->
    <link href="<?php echo base_url();?>assets/css/color.css" rel="stylesheet" />
    <!-- Responsive CSS -->
    <link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet" />
    <!-- SELECT MENU -->
    <link href="<?php echo base_url();?>assets/css/selectric.css" rel="stylesheet" />
    <!-- SIDE MENU -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.sidr.dark.css" />
    <!--welcome-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style >
      .cardsh{
        box-shadow: 4px 2px 2px 0px #dcdada;
      }
      .cardsh1{
        box-shadow: -4px 2px 2px 0px #dcdada;
      }
      .cardsh:hover{
        box-shadow: 8px 5px 4px 0px #dcdada;
      }
      .cardsh1:hover{
        box-shadow: -8px 5px 4px 0px #dcdada;
      }
    </style>
  </head>
  <!--HEADER START-->
  <header id="header_2">
    <!--kode top bar start-->
    <div class="top_bar_2">
      <div class="container">
        <div class="row">
          <div class="col-md-5">
            <div class="pull-left">
              <li class="contct_2">
                <i class="fa fa-phone">
                </i> 0821 254 8318
                <i class="fa fa-envelope">
                </i>jss418@yahoo.com
              </li>
            </div>
          </div>
          <div class="col-md-7">
            <div class="lng_wrap">
              <div class="dropdown">                                    
              </div>
            </div>
            <ul class="login_wrap">
              <li>
                <a href="#" data-toggle="modal" data-target="#reg-box">
                  <i class="fa fa-user">
                  </i>Register
                </a>
              </li>
              <li>
                <a href="login" >
                  <i class="fa fa-sign-in">
                  </i>Sign In
                </a>
              </li>
            </ul>                   
          </div>
        </div>
      </div>
    </div>
    <!--kode top bar end-->
    <!--kode navigation start-->
       <div class="kode_navigation">
      <div id="mobile-header">
        <a id="responsive-menu-button" href="#sidr-main">
          <i class="fa fa-bars">
          </i>
        </a>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-2">
            <div class="logo_wrap">
              <a href="#">
                <img src="<?php echo base_url(); ?>assets/images/logo/logo1.png" alt="" style="position:  absolute; left: -44px; top: 13px" />
              </a>
            </div>
          </div>
          <div class="col-md-10">
            <!--kode nav_2 start-->
            <div class="nav_2" id="navigation">
              <ul>
                <li>
                  <a href="index.php">home
                  </a>
                </li>
                <li>
                  <a href="index.php/aboutus">About Us  
                    <i class="fa fa-caret-down">
                    </i>
                  </a>
                  <ul>
                    <li>
                      <a href="aboutus" style="border-bottom: solid #a2a1a1 1px;">Jss Mahavidyapeeta
                      </a>
                    </li>
                    <li>
                      <a href="index.php/aboutus/JSSVP" style="border-bottom: solid #a2a1a1 1px;">Jss Polytechnic 
                      </a>
                    </li>                                   
                  </ul> 
                </li>   
                <li>
                  <a href="Departments">Departments  
                    <i class="fa fa-caret-down">
                    </i>
                  </a>
                  <ul>
                    <li>
                      <a href="Departments/mech" style="border-bottom: solid #a2a1a1 1px;">Mechanical Engineering
                      </a>
                    </li>
                    <li>
                      <a href="Departments/civil" style="border-bottom: solid #a2a1a1 1px;">Civil Engineering
                      </a>
                    </li>
                    <li>
                      <a href="Departments/mecron" style="border-bottom: solid #a2a1a1 1px;">Mecetronics Engineering
                      </a>
                    </li>
                    <li>
                      <a href="Departments/cs" style="border-bottom: solid #a2a1a1 1px;">Computer Science & Engg
                      </a>
                    </li>
                    <li>
                      <a href="Departments/IS" style="border-bottom: solid #a2a1a1 1px;">Information Science & Engg
                      </a>
                    </li>
                    <li>
                      <a href="Departments/EC" style="border-bottom: solid #a2a1a1 1px;">Electronics & Communication Engg
                      </a>
                    </li>
                    <li>
                      <a href="Departments/EE" style="border-bottom: solid #a2a1a1 1px;">Electonics & Electricals Engg
                      </a>
                    </li>
                    <li>
                      <a href="Departments/EE" style="border-bottom: solid #a2a1a1 1px;">Basic Science
                      </a>
                    </li>
                  </ul>         
                </li>
                <li>
                  <a href="acti.php">Activities  
                    <i class="fa fa-caret-down">
                    </i>
                  </a>
                  <ul>
                    <li>
                      <a href="ncc" style="border-bottom: solid #a2a1a1 1px;">NCC
                      </a>
                    </li>
                    <li>
                      <a href="Nss.php" style="border-bottom: solid #a2a1a1 1px;">NSS
                      </a>
                    </li>
                  </ul>                         
                </li>
                <li>
                  <a href="news">News
                  </a>
                </li>
                <li>
                  <a href="gal">Gallery
                  </a>  
                </li>
                <li>
                  <a href="contactus">Contact US
                  </a>                                      
                </li>
                
              </ul>
            </div>
            <!--kode nav_2 end-->
          </div>
        </div>
      </div>
    </div>
    <!--kode navigation end-->
  </header>
  <!--HEADER END-->