<?php include('login_head.php'); ?>
<body background="<?php echo base_url();?>assets/images/login/back.jpg">

 <div class="container">
        <div class="card card-container">

            
            <img id="profile-img" class="profile-img-card" src="<?php echo base_url();?>assets/images/login/logo.png" alt="1111" />
            <p id="profile-name" class="profile-name-card"></p>
            <form class="form-signin">
                <span id="reauth-email" class="reauth-email"></span>
                
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
                <input type="password" id="inputPassword" class="form-control" placeholder="Password" required>
                <div id="remember" class="checkbox">
                    <label>
                        <input type="checkbox" value="remember-me"> Remember me
                    </label>
                </div>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Sign in</button>
            </form><!-- /form -->
            <a href="#" class="forgot-password">
                <b>Forgot the password?</b>
            </a>
        </div><!-- /card-container -->
    </div><!-- /container -->
<?php include('login_foot.php'); ?>