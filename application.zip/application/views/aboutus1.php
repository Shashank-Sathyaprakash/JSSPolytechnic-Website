<?php include('header.php'); ?>
<!--Banner Wrap Start-->
<div class="kf_inr_banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <!--KF INR BANNER DES Wrap Start-->
        <div class="kf_inr_ban_des">
          <div class="inr_banner_heading">
            <h3>about us
            </h3>
          </div>
          <div class="kf_inr_breadcrumb">
            <ul>
              <li>
                <a href="#">Home
                </a>
              </li>
              <li>
                <a href="#">about us
                </a>
              </li>
            </ul>
          </div>
        </div>
        <!--KF INR BANNER DES Wrap End-->
      </div>
    </div>
  </div>
</div>
<!--Banner Wrap End-->
<!--Content Wrap Start-->
<div class="kf_content_wrap">
  <!--ABOUT UNIVERSITY START-->
  <section>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="abt_univ_wrap">
            <!-- HEADING 1 START-->
            <div class="kf_edu2_heading1">
              <h5>About Our JSS polytechnic
              </h5>
              <h3>Welcome To JSS POLYTECHNIC
              </h3>
            </div>
            <!-- HEADING 1 END-->
            <div class="abt_univ_des">
              <p>The polytechnic is situated on an extensive 6 hectares of land in 'JSS TECHNICAL INSTITUTIONS' CAMPUS, to the west of University of Mysore, Manasagangothri. It is located at about 6 kms from KSRTC Bus stand and 5 kms from the Railway station. It is recognized by the Government of Karnataka and approved by the All India Council for Technical Education, New Delhi
                Full fledged branches of Punjab National Bank & Syndicate Bank, Health Centre, Cafeteria, a few shops to cater to the needs of the students and staff are functioning in the campus.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="abt_univ_thumb">
            <figure>
              <img src="<?php echo base_url();?>assets/images/about/JSSP.jpg" alt="" style="margin-top: 110px;"/>
            </figure>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--ABOUT UNIVERSITY END-->
  <!--KF EDUCATION STUDENT SLIDER WRAP START-->
  <section class="edu_student_wrap_bg">
    <div class="container">
      <div class="student_slider_wrap">
        <div class="row">
          <div class="col-md-6">
            <ul class="bxslider">
              <li>
                <!-- STUDENT SLIDER DES START-->
                <div class="student_slider_des">
                  <!-- HEADING 1 START-->
                  <div class="kf_edu2_heading1">
                    <h3>From Principal's DesK
                    </h3>
                  </div>
                  <!-- HEADING 1 END-->
                  <p>The polytechnic is situated on an extensive 6 hectares of land in 'JSS TECHNICAL INSTITUTIONS' CAMPUS, to the west of University of Mysore, Manasagangothri. It is located at about 6 kms from KSRTC Bus stand and 5 kms from the Railway station. It is recognized by the Government of Karnataka and approved by the All India Council for Technical Education, New Delhi
                    Full fledged branches of Punjab National Bank & Syndicate Bank, Health Centre, Cafeteria, a few shops to cater to the needs of the students and staff are functioning in the campus.
                  </p>
                  <div class="std_name_des">
                    <a href="#">Mr Ramlinga Gowda
                    </a>
                    <small>Principal,JSS Polytechnic
                    </small>
                  </div>
                </div>
                <!-- STUDENT SLIDER DES END-->
              </li>
            </ul>
          </div>
          <div class="col-md-6">
            <div class="abt_univ_thumb">
              <figure>
                <img src="<?php echo base_url();?>assets/images/about/principal.jpg" height="450px" alt="principals image" />
              </figure>
            </div>
          </div>
          <!-- STUDENT SLIDER THUMB DES END-->
        </div>
      </div>
    </div>
    </div>
  </section>
<!--KF EDUCATION STUDENT SLIDER WRAP END-->
<!-- works and mission secion-->
<div class="kf_inr_banner">
  <div class="container">
    <div class="row">
      <h3>
        <center> 
          <b>
            <font color="white"/>OUR MISION 
          </b>
        </center>
      </h3>
    </div>
    <br>
    <div>
      <center>To build and enhance a conducive environment for students from different walks of life to learn quality technical education and to become enviable diploma professtionals who can meet the demands of the present highly competitive world at all levels without letting down their pristine nation honour.
      </center>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>