<?php include('header.php'); ?>
<!--Content Wrap Start-->
<section>
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url();?>assets/images/me/me.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Mechanical Engineering
            </h6>
            <ul>
              <li>HOD: Mr.Rajashekara.H.M.Hangala
              <li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma
              </li>
              <br>
            </ul>
            <a href="#" class="btn-1">read more
            </a>
          </div>
          <!--EDU2 COLUM 3 Des End-->
        </div>
        <!--EDU2 COLUM 3 Wrap End-->
      </div>
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url(); ?>assets/images/civil/civil.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Civil Engineering
            </h6>
            <ul>
              <li> HOD: Mr. Channamallikarjuna
              </li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma
              </li>
              <br>                                
            </ul>
            <a href="#" class="btn-1">read more
            </a>
          </div>
          <!--EDU2 COLUM 3 Des End-->
        </div>
        <!--EDU2 COLUM 3 Wrap End-->
      </div>
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url(); ?>assets/images/mc/mc.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Mechatronics Engineering
            </h6>
            <ul>
              <li>HOD: Mrs.Manjula.M
              </li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma 
              </li>
              <br>                                    
            </ul> 
            <a href="#" class="btn-1">read more
            </a>                            
          </div>
          <!--EDU2 COLUM 3 Des End-->
        </div>
        <!--EDU2 COLUM 3 Wrap End-->
      </div>
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url(); ?>assets/images/cs/cs.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Computer Science & Engg
            </h6>
            <ul>
              <li>HOD: Mrs.Shinu Koshy
              </li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma
              </li> 
              <br>                                    
            </ul>
            <a href="#" class="btn-1">read more
            </a>     
          </div>
          <!--EDU2 COLUM 3 Des End-->
        </div>
        <!--EDU2 COLUM 3 Wrap End-->
      </div>
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url(); ?>assets/images/is/is.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Information Science & Engg
            </h6>
            <ul>
              <li>HOD: Mr.Shivaswamy.M
              </li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma 
              </li>
              <br>                                    
            </ul>
            <a href="#" class="btn-1">read more
            </a>     
          </div>
          <!--EDU2 COLUM 3 Des End-->
        </div>
        <!--EDU2 COLUM 3 Wrap End-->
      </div>
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url(); ?>assets/images/ec/ec.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Electronics and Communication in Engg
            </h6>
            <ul>
              <li>HOD: Mrs.Asha kulkarni
              </li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma
              </li> 
              <br>                                    
            </ul>     
            <a href="#" class="btn-1">read more
            </a>
          </div>
          <!--EDU2 COLUM 3 Wrap End-->
        </div>
      </div>
      <div class="col-md-4 col-sm-6">
        <!--EDU2 COLUM 3 Wrap Start-->
        <div class="edu2_col_3_wrap">
          <figure>
            <img src="<?php echo base_url(); ?>assets/images/ee/ee.jpg" alt="" />
          </figure>
          <!--EDU2 COLUM 3 Des Start-->
          <div class="edu2_col_3_des">
            <h6>Electrical & Electronics Engineering
            </h6>
            <ul>
              <li>HOD: Mrs.Prathibha.D
              </li>
              <li>Course Durartion: 3Yrs
              </li>
              <li>Degree Level: Diploma
              </li> 
              <br>                                    
            </ul>    
            <a href="#" class="btn-1">read more
            </a> 
          </div>
          <!--EDU2 COLUM 3 Wrap End-->
        </div>
      </div>
      <!--KF_PAGINATION_WRAP END-->
    </div>
  </div>
</section>
<!--Content Wrap End-->
<?php include('footer.php'); ?>
