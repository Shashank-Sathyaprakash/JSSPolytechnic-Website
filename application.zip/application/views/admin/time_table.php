<?php include "header.php"; ?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-color panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Syllabus details
              </h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-lg-10 col-lg-offset-1">
                  <form class="form-horizontal" role="form" action="<?php echo base_url();?>index.php/admin/adddeptdeatils" method="post" role="form">
                    <div class="form-group">
                      <label class="col-sm-3 control-label">Dept Name
                      </label>
                      <div class="col-sm-1" style="width: 95px;">
                        <select class="form-control" name="dept">
                          <option>CS
                          </option>
                          <option>ME
                          </option>
                          <option>CE
                          </option>
                          <option>MC
                          </option>
                          <option>IS
                          </option>
                          <option>EE
                          </option>
                          <option>EC
                          </option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
              <label class="col-sm-3 control-label">Sem
              </label>
              <div class="col-sm-1">
                <select class="form-control" style="width: 95px;" name="sem">
                  <option>1
                  </option>
                  <option>2
                  </option>
                  <option>3
                  </option>
                  <option>4
                  </option>
                  <option>5
                  </option>
                  <option>6
                  </option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Choose File
              </label>
              <div class="col-md-4">
                <input type="file">
                </input>
              <br>
              <br>
              <div class="form-group">
                <div class="col-sm-offset-3 col-sm-9 m-t-15">
                  <button type="submit" class="btn btn-primary waves-effect waves-light">
                    Submit
                  </button>
                  
                </div>
              </div>
            </div>
            </div>
          </form>
            </div>
            </div>
        </div>
    </div>
        <div class="row">
          <div class="col-sm-12">
            <div class="card-box table-responsive">
              <h4 class="header-title m-t-0 m-b-30">Details
              </h4>
              <table id="datatable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>SL.No
                    </th>
                    <th>Dept Name
                    </th>
                    <th>Semester
                    </th>
                    <th>file
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
$i=0;
foreach($time_table as $row){
$i++;
?>
                  <tr>
                    <td>
                      <?php echo $i;?>
                    </td>
                    <td>
                      <?php echo $row['department'];?>
                    </td>
                    <td>
                      <?php echo $row['semester'];?>
                    </td>
                    <td>
                      <?php echo $row['file'];?>
                    </td>
                    <td class="actions">
                      <a href="#" class="hidden on-editing save-row">
                        <i class="fa fa-save">
                        </i>
                      </a>
                      <a href="#" class="hidden on-editing cancel-row">
                        <i class="fa fa-times">
                        </i>
                      </a>
                      <a href="#" class="on-default edit-row">
                        <i class="fa fa-pencil">
                        </i>
                      </a>
                      <a href="#" class="on-default remove-row">
                        <i class="fa fa-trash-o">
                        </i>
                      </a>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- end col -->
        </div>
        </body>
      <?php include "footer.php"; ?>
<script type="text/javascript">
        $(document).ready(function() 
                          {
          $('.page-title').text('TimeTable')
        });
      </script>