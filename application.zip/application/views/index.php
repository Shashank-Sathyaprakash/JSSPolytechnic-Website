<?php include('header.php'); ?>
<body>
    <!--slider-->
    <div class="edu2_main_bn_wrap">
      <div id="owl-demo-23" class="owl-carousel owl-theme">
        <div class="item">
          <figure>
            <img src="<?php echo base_url();?>assets/images/slider/sl2.jpg" alt="cannot be displayed" />
            <figcaption>
              <h2>welcome to JSS Polytechnic
              </h2>
              <p>We Belive there is nothing more important than Education.
              </p>
            </figcaption>
          </figure>
        </div>
        <div class="item">
          <figure>
            <img src="<?php echo base_url();?>assets/images/slider/sl31.jpg" alt="cannot be displayed" />
            <figcaption>
              <h2>We bring new online courses
              </h2>
              <p>Largest Online Courses available here.
              </p>
            </figcaption>
          </figure>
        </div>
      </div>
    </div>
    <!--end of slider-->
    <section>
      <div class="col-md-6" style="margin-top: 55px;">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/9M8UOTWwE6w" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>
        </iframe>
      </div>
      <div class="col-md-6">
        <div class="kf_edu2_heading2">
          <h3>Welcome To JSS Polytechnic
          </h3>
        </div>
        <div class="content-desc">
          <div class="">
            <p class="lead">
            </p>
          </div>
          <div class="about_texts">
            <p>The polytechnic is situated on an extensive 6 hectares of land in 'JSS TECHNICAL INSTITUTIONS' CAMPUS, to the west of University of Mysore, Manasagangothri. It is located at about 6 kms from KSRTC Bus stand and 5 kms from the Railway station. It is recognized by the Government of Karnataka and approved by the All India Council for Technical Education, New Delhi.
            </p>
            <p>Full fledged branches of Punjab National Bank & Syndicate Bank, Health Centre, Cafeteria, a few shops to cater to the needs of the students and staff are functioning in the campus.    
            </p>
          </div>                                                
        </div>
        </section>
      <!--KF INTRO WRAP END-->
      <div class="kf_content_wrap">
        <!--COURSE OUTER WRAP START-->
        <div class="kf_course_outerwrap">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
                <div class="row">
                  <!--COURSE CATEGORIES WRAP START-->
                  <div class="kf_cur_catg_wrap">
                    <!--COURSE CATEGORIES WRAP HEADING START-->
                    <div class="col-md-12">
                      <div class="kf_edu2_heading1">
                        <h3>Our Course
                        </h3>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES WRAP HEADING END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-1">
                        <span>
                          <i class="fa fa-wrench">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <a href="me.php">
                          <h5>Mechanical Engineering
                          </h5>
                          <p>Mechanical engineering is a professional programme which helps students to understand the working mechanisms of  machineries
                          </p>
                          </a>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-2">
                        <span>
                          <i class="fa fa-building">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Civil Engineering
                          </h5>
                          <p>It is a professional engineering discipline that deals with the design, construction of the physical and naturally built environment,
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-3">
                        <span>
                          <i class="fa fa-automobile">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Mechactronics Engineering
                          </h5>
                          <p>It is a multidisciplinary field of science that includes a combination of mechanical engineering, electronics, computer engineering. 
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-4">
                        <span>
                          <i class="fa fa-desktop">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Computer Science 
                          </h5>
                          <p>It is a discipline that integrates several fields of electrical engineering and computer science required to develop computer hard and softwares.
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-5">
                        <span>
                          <i class="fa fa-desktop">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Information Science
                          </h5>
                          <p>It is the use of computers to store, retrieve, transmit and manipulate data, or information, often in the context of a enterprise.
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-6">
                        <span>
                          <i class="fa fa-flash">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Electronis & communication Engg
                          </h5>
                          <p>It is an electrical engineering discipline which utilizes nonlinear and active electrical components to design electronic circuits, devices, VLSI devices.
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-6">
                        <span>
                          <i class="fa fa-flash">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Electronic & Electricals
                          </h5>
                          <p>It have contributed to the development of a wide range of technologies. They design, develop, test, and supervise the deployment of electrical systems. 
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                    <!--COURSE CATEGORIES DES START-->
                    <div class="col-md-6">
                      <div class="kf_cur_catg_des color-6">
                        <span>
                          <i class="fa fa-flask">
                          </i>
                        </span>
                        <div class="kf_cur_catg_capstion">
                          <h5>Basic Science
                          </h5>
                          <p>It focuses on the development of technology and techniques. In contrast, basic science develops scientific knowledge and predictions.
                          </p>
                        </div>
                      </div>
                    </div>
                    <!--COURSE CATEGORIES DES END-->
                  </div>
                  <!--COURSE CATEGORIES WRAP END-->
                </div>
              </div>
              <div class="col-md-4">
                <!-- EDU2 SEARCH WRAP START -->
                <div class="kf_edu2_search_wrap" style="margin-top: 135px; box-shadow: 0 0 4px 1px #ceb9b9;">
                  <div class="kf_edu2_heading1">
                    <h3>Latest Events
                    </h3>
                    <hr>
                    <marquee direction="up" style="height: 855px;">
                     <p>Theory exams starts from 17/05/18
                      </p>
                      <br>
                      <p>practical Exam Starts from 19/04/18
                      </p>
                      <br>
                      <p>Exam hall tickets will be issued on 15/04/18
                      </p>
                      <br>
                      <p>Annual day of the college will be on 12/04/18 @ JSS Polytechnic
                      </p>
                      <br>
                      <p>Sendoff for final year student will be on 12/04/18 @ JSS Polytechnic
                      </p>
                      <br>                  
                      <p>Ethinic day for college is on 11/04/18 @ JSS Polytechnic
                      </p>
                      <br>
                      <p>Sports day will be conducted for stdents on 7/04/18-8/04/18 @ JSS Public school
                      </p>
                    </marquee>
                  </div>
                  <!-- EDU2 SEARCH WRAP END -->
                </div>
              </div>
            </div>
          </div>
          <!--COURSE OUTER WRAP END-->
          <!--KF COURSES CATEGORIES WRAP START-->

          <!--Facilities SECTION START-->
          <section class="kode-gallery-section">
            <!-- HEADING 2 START-->
            <div class="col-md-12">
              <div class="kf_edu2_heading2">
                <h3>Facilities
                </h3>
                <ph>The facilities provided in our college
                  </p>
              </div>
            </div>
            <!-- HEADING 2 END-->
            <!-- EDU2 GALLERY WRAP START-->
            <div class="edu2_gallery_wrap gallery">
              <!-- Library section Start-->
              <div class="gallery3">
                <div class="filterable-item all 2 1 9 col-md-3 col-sm-4 col-xs-12 no_padding">
                  <div class="edu2_gallery_des">
                    <figure>
                      <img alt="" src="<?php echo base_url();?>assets/images/facilities/lib.jpg" />
                      <figcaption>
                        <a data-rel="prettyPhoto[gallery2]" href="<?php echo base_url();?>assets/images/facilities/lib.jpg">
                          <i class="fa fa-eye">
                          </i>
                        </a>
                        <a href="gallery">
                          <i class="fa fa-link">
                          </i>
                        </a>
                        <h5>LIBRARY
                        </h5>
                        <p>Convocation
                        </p>
                      </figcaption>
                    </figure>
                  </div>    
                </div>
                <!-- Library section End-->

                <!-- Hostel section Start-->
                
                <div class="filterable-item all 3 2 1 col-md-3 col-sm-4 col-xs-12 no_padding">
                  <div class="edu2_gallery_des">
                    <figure>
                      <img alt="" src="<?php echo base_url();?>assets/images/facilities/hostel.jpg" />
                      <figcaption>
                        <a data-rel="prettyPhoto[gallery2]" href="<?php echo base_url();?>assets/images/hostel.jpg">
                          <i class="fa fa-eye">
                          </i>
                        </a>
                        <a href="gallery">
                          <i class="fa fa-link">
                          </i>
                        </a>
                        <h5>HOSTEL
                        </h5>
                        <p>Convocation
                        </p>
                      </figcaption>
                    </figure>
                  </div>    
                </div>
                <div class="filterable-item all 4 2 9 col-md-3 col-sm-4 col-xs-12 no_padding">
                  <div class="edu2_gallery_des">
                    <figure>
                      <img alt="" src="<?php echo base_url();?>assets/images/facilities/canteen.jpg" />
                      <figcaption>
                        <a data-rel="prettyPhoto[gallery2]" href="<?php echo base_url();?>assets/images/facilities/canteen.jpg">
                          <i class="fa fa-eye">
                          </i>
                        </a>
                        <a href="gallery">
                          <i class="fa fa-link">
                          </i>
                        </a>
                        <h5>CANTEEN
                        </h5>
                        <p>Convocation
                        </p> 
                      </figcaption>
                    </figure>
                  </div>    
                </div>
                <div class="filterable-item all 9 8 7 col-md-3 col-sm-4 col-xs-12 no_padding">
                  <div class="edu2_gallery_des">
                    <figure>
                      <img alt="" src="<?php echo base_url();?>assets/images/facilities/labs1.jpg" />
                      <figcaption>
                        <a data-rel="prettyPhoto[gallery2]" href="<?php echo base_url();?>assets/images/facilities/labs1.jpg">
                          <i class="fa fa-eye">
                          </i>
                        </a>
                        <a href="gallery">
                          <i class="fa fa-link">
                          </i>
                        </a>
                        <h5>LABS
                        </h5>
                        <p>Convocation
                        </p>
                      </figcaption>
                    </figure>
                  </div>    
                </div>
                <!-- EDU2 GALLERY WRAP END-->
              </div>
              </section>
            <!--FACILITY SECTION END-->
            <!--COUNTER SECTION START-->
            <section class="edu2_counter_wrap">
              <div class="container">
                <!--EDU2 COUNTER DES START-->
                <div class="edu2_counter_des">
                  <span>
                    <i class="icon-group2">
                    </i>
                  </span>
                  <h3 class="counter">9500
                  </h3>
                  <h5>STUDENTS ENROLLED
                  </h5>
                </div>
                <!--EDU2 COUNTER DES END-->
                <!--EDU2 COUNTER DES START-->
                <div class="edu2_counter_des">
                  <span>
                    <i class="icon-book236">
                    </i>
                  </span>
                  <h3 class="counter">2050
                  </h3>
                  <h5>NUMBER OF BOOKS   
                  </h5>
                </div>
                <!--EDU2 COUNTER DES END-->
                <!--EDU2 COUNTER DES START-->
                <div class="edu2_counter_des">
                  <span>
                    <i class="icon-win5">
                    </i>
                  </span>
                  <h3 class="counter">5000
                  </h3>
                  <h5>STUDENT PASSED OUT
                  </h5>
                </div>
                <!--EDU2 COUNTER DES END-->
                <!--EDU2 COUNTER DES START-->
                <div class="edu2_counter_des">
                  <span>
                    <i class=" icon-user255">
                    </i>
                  </span>
                  <h3 class="counter">370
                  </h3>
                  <h5>CERTIFIED TEACHERS
                  </h5>
                </div>
                <!--EDU2 COUNTER DES END-->
              </div>
            </section>
            <!--COUNTER SECTION END-->
            <!-- FACULTY DES END-->
            </div>
          <!-- FACULTY SLIDER WRAP END-->
        </div>
      </div>
    </section>
    <!-- FACULTY WRAP START-->
    <!-- LATEST NEWS AND EVENT WRAP START-->
    <section class="edu2_new_wrap">
      <div class="container">
        <!-- HEADING 2 START-->
        <div class="col-md-12">
          <div class="kf_edu2_heading2">
            <h3>Latest News 
            </h3>
          </div>
        </div>
        <!-- HEADING 2 END-->
        <div class="row">
          <!-- EDU2 NEW DES START-->
          <div class="col-md-6">
            <div class="edu2_new_des">
              <div class="row cardsh1">
                <div class="col-md-6 col-sm-6">
                  <div class="edu2_event_des">
                    <h4>Mar
                    </h4>
                    <p>CS and IS Dept made A visit to Indian Institute Of Science 
                    </p>
                    <ul class="post-option">
                      <li>By
                        <a href="#">Admin
                        </a>
                      </li>
                      <li>17/3/2018
                      </li>
                    </ul>
                    <a href="#" class="readmore">read more
                      <i class="fa fa-long-arrow-right">
                      </i>
                    </a>
                    <span>16
                    </span>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 thumb">
                  <figure>
                    <img src="<?php echo base_url();?>assets/images/events/iisc.jpg" alt="" />
                    <figcaption>
                      <a href="news.php">
                        <i class="fa fa-plus">
                        </i>
                      </a>
                    </figcaption>
                  </figure>
                </div>
              </div>
            </div>
          </div>
          <!-- EDU2 NEW DES END-->
          <!-- EDU2 NEW DES START-->
          <div class="col-md-6">
            <div class="edu2_new_des">
              <div class="row cardsh">
                
                  <div class="col-md-6 col-sm-6 thumb">
                    <figure>
                      <img src="<?php echo base_url();?>assets/images/events/M_track.jpg" alt="" />
                      <figcaption>
                        <a href="./blog-detail.html">
                          <i class="fa fa-plus">
                          </i>
                        </a>
                      </figcaption>
                    </figure>
                  </div>
                  <div class="col-md-6 col-sm-6">
                     <div class="edu2_event_des">
                    <h4>Mar
                    </h4>
                    <p>CS and IS Dept made A visit to M-Tracking
                    </p>
                    <ul class="post-option">
                      <li>By
                        <a href="gallery">Admin
                        </a>
                      </li>
                      <li>22/03/2018
                      </li>
                      <li>
                        <a href="#">
                        </a>
                      </li>
                    </ul>
                    <a href="#" class="readmore">read more
                      <i class="fa fa-long-arrow-right">
                      </i>
                    </a>
                    <span>20
                    </span>
                  </div>
              </div>
            </div>
          </div>
        </div>
        <!-- EDU2 NEW DES END-->
        <!-- EDU2 NEW DES START-->
        <div class="col-md-6">
          <div class="edu2_new_des">
            <div class="row cardsh1">
              <div class="col-md-6 col-sm-6">
                <div class="edu2_event_des">
                  <h4>Mar
                  </h4>
                  <p>CS branch made a visit to NIE college to Learn about Internet of things
                  </p>
                  <ul class="post-option">
                    <li>By
                      <a href="#">Admin
                      </a>
                    </li>
                    <li>27/03/2018
                    </li>
                  </ul>
                  <a href="#" class="readmore">read more
                    <i class="fa fa-long-arrow-right">
                    </i>
                  </a>
                  <span>26
                  </span>
                </div>
              </div>
              <div class="col-md-6 col-sm-6 thumb">
                <figure>
                  <img src="<?php echo base_url();?>assets/images/events/IOT.jpg" alt="" />
                  <figcaption>
                    <a href="./blog-detail.html">
                      <i class="fa fa-plus">
                      </i>
                    </a>
                  </figcaption>
                </figure>
              </div>
            </div>
          </div>
        </div>
        <!-- EDU2 NEW DES END-->
        <!-- EDU2 NEW DES START-->
        <div class="col-md-6">
          <div class="edu2_new_des">
            <div class="row cardsh">
              <div class="col-md-6 col-sm-6 thumb">
                <figure>
                  <img src="<?php echo base_url();?>assets/images/events/ethinic.jpg" alt="" />
                  <figcaption>
                    <a href="./blog-detail.html">
                      <i class="fa fa-plus">
                      </i>
                    </a>
                  </figcaption>
                </figure>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="edu2_event_des">
                  <h4>April
                  </h4>
                  <p>Ethinic day was held @ Our colleage where all students upheld their tradition
                  </p>
                  <ul class="post-option">
                    <li>By
                      <a href="#">Admin
                      </a>
                    </li>
                    <li>12/04/2018
                    </li>
                  </ul>
                  <a href="#" class="readmore">read more
                    <i class="fa fa-long-arrow-right">
                    </i>
                  </a>
                  <span> 11
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- EDU2 NEW DES END-->
      </div>
      </div>
  </div>
  </section>
<!-- LATEST NEWS AND EVENT WRAP END-->
<!--OUR TESTEMONIAL WRAP START-->
<section>
  <div class="container">
    <div class="row">
      <!-- HEADING 2 START-->
      <div class="col-md-12">
        <div class="kf_edu2_heading2">
          <h3>Our Testimonial
          </h3>
        </div>
      </div>
      <!-- HEADING 2 END-->
      <!-- TESTEMONIAL SLIDER WRAP START-->
     <div class="edu2_testemonial_slider_wrap">.
    
        <div id="owl-demo-9" id="owl-demo-23" class="owl-carousel owl-theme">

          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure style=" border-radius: 75%;">
                <img src="<?php echo base_url();?>assets/images/testimonials/dheeraj.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>It has got an excellent infrastructure. Well equipped laboratories. An excellent library. The faculties are really cooperative. College also encourages extra circular activities.
                </p>
                <a href="#">Dheeraj.S
                  <span>
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure style=" border-radius: 75%;">
                <img src="<?php echo base_url();?>assets/images/testimonials/shashank.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>Overall experience was good. infrastructure is also good. College provides various platforms to enhance their skills in different areas.Best facilities
                </p>
                <a href="#">Shashank.S
                  <span>
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="<?php echo base_url();?>assets/images/testimonials/testemonial.1.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="<?php echo base_url();?>assets/images/testimonials/testemonial.2.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="<?php echo base_url();?>assets/images/testimonials/testemonial.1.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
          <div class="item">
            <!-- TESTEMONIAL SLIDER WRAP START-->
            <div class="edu_testemonial_wrap">
              <figure>
                <img src="<?php echo base_url();?>assets/images/testimonials/testemonial.2.jpg" alt="" />
              </figure>
              <div class="kode-text">
                <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet.aenean sollicitudin, lorem quis bibendum auctor...
                </p>
                <a href="#">John Doe
                  <span>- Happy Student
                  </span>
                </a>
              </div>
            </div>
            <!-- TESTEMONIAL SLIDER WRAP END-->
          </div>
        </div>
      </div>
      <!-- TESTEMONIAL SLIDER WRAP END-->
    </div>
  </div>
</section>
<!--OUR TESTEMONIAL WRAP END-->
</div>
<!--EDU2 FOOTER WRAP START-->
<?php include('footer.php'); ?>
</body>
</html>