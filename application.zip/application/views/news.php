<?php include('header.php'); ?>
<div class="kf_inr_banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <!--KF INR BANNER DES Wrap Start-->
        <div class="kf_inr_ban_des">
          <div class="inr_banner_heading">
            <h3>Event Detail
            </h3>
          </div>
          <div class="kf_inr_breadcrumb">
            <ul>
              <li>
                <a href="#">Home
                </a>
              </li>
              <li>
                <a href="#">Event Detail
                </a>
              </li>
            </ul>
          </div>
        </div>
        <!--KF INR BANNER DES Wrap End-->
      </div>
    </div>
  </div>
</div>
<!--Banner Wrap End-->
<!--Content Wrap Start-->
<div class="kf_content_wrap">
  <section>
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <!--EVENT CONVOCATION OUTER Wrap START-->
          <div class="kf_convocation_outer_wrap">	
            <div class="convocation_slider">
              <div id="owl-demo-23" class="owl-carousel owl-theme">
                <div class="item">
                  <figure>
                    <img src="<?php echo base_url();?>assets/images/events/ethi.jpg" alt="" />
                  </figure>
                </div>
                <div class="item">
                  <figure>
                    <img src="<?php echo base_url();?>assets/images/events/ethi1.jpg" alt="" />
                  </figure>
                </div>

              </div>
            </div>
            <!--EVENT CONVOCATION  Wrap START-->
            <div class="kf_convocation_wrap">
              <h4>
                <span>Ethinic 
                </span> for Our Students
              </h4>
              <ul class="convocation_timing">
                <li>
                  <i class="fa fa-calendar">
                  </i>11 April, 2018
                </li>
                <li>
                  <i class="fa fa-clock-o">
                  </i>10:00 am - 02:00 pm
                </li>
              </ul>
              <!--EVENT CONVOCATION DES START-->
              <div class="kf_convocation_des">
                <h5>It was not just another normal day in the Department as the campus was decorated in a traditional way. The energy levels were quite high as the campus was bursting with enthusiasm and passion. 
                </h5>
                <p>       As a part of our College, The faculty and students joined hands to celebrate and showcase our regional culture and tradition to everyone present on campus by celebrating ETHNIC DAY.<br>

                   Girls were dressed in Ghagharas, Lehngas and traditional Sarees and the boys wore lungis, dhothis and even be jewelled turbans, like those worn by kings in ancient times. CSE students were not been seen anywhere wearing Jeans and T-shirts in the sprawling grounds.
                </p>
                
                <!--EVENT CONVOCATION MAP  Wrap START-->
                
                <!--EVENT CONVOCATION MAP  Wrap END-->
              </div>
              <!--EVENT CONVOCATION DES END-->
            </div>
            <!--EVENT CONVOCATION  Wrap END-->
            <!--EVENT SPEAKER Wrap START-->
            <div class="kf_event_speakers">
              <div class="heading_5">
                <h4>
                  <span>Event
                  </span> Speakers
                </h4>
              </div>
              <div class="row">
                <div class="col-md-4 col-sm-4">
                  <div class="kf_event_speakers_des">
                    <figure>
                      <img src="<?php echo base_url();?>assets/images/news/Aruna J.jpg" alt="" style="margin-top: 30px;" />
                    </figure>
                    <h5>
                      <a href="#">Arun J
                      </a>
                    </h5>
                    <p>Lucturer
                    </p>
                    <p>IS Department
                    </p>
                  </div>
                </div>
                </div>
            </div>

            <!--EVENT SPEAKER Wrap End-->
            <!--EVENT GALLERY Wrap STAT-->
            <div class="kf_event_gallery">
              <div class="heading_5">
                <h4>
                  <span>Event
                  </span> Gallery
                </h4>
              </div>
              <ul class="event_gallery_des">
                <li>
                  <a href="#">
                    <img src="<?php echo base_url();?>assets/images/news/tec1.jpg" alt="" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <img src="<?php echo base_url();?>assets/images/news/tec2.jpg" alt="" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <img src="<?php echo base_url();?>assets/images/news/tec.jpg" alt="" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <img src="<?php echo base_url();?>assets/images/news/cs.jpg" alt="" />
                  </a>
                </li>
                <li>
                  <a href="#">
                    <img src="<?php echo base_url();?>assets/images/news/is.jpg" alt="" />
                  </a>
                </li>

                <li>
                  <a href="#">
                    <img src="<?php echo base_url();?>assets/images/news/grp.jpg" alt="" />
                  </a>
                </li>
              
              </ul>
              <a class="event_link next" href="#">NEXT EVENT
                <i class="fa fa-angle-right">
                </i>
              </a>
              <a class="event_link prev" href="#">
                <i class="fa fa-angle-left">
                </i>PREVIOUS EVENT
              </a>
            </div>
            <!--EVENT GALLERY Wrap End-->
          </div>
          <!--EVENT CONVOCATION OUTER Wrap END-->
        </div>
		</div>
	</div>
</section>
</div>
        <!--KF_EDU_SIDEBAR_WRAP START-->
        <!--Content Wrap End-->
        <?php include('footer.php'); ?>
