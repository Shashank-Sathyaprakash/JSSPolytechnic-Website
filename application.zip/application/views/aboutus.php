<?php include('header.php'); ?>
<!--Banner Wrap Start-->
<div class="kf_inr_banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <!--KF INR BANNER DES Wrap Start-->
        <div class="kf_inr_ban_des">
          <div class="inr_banner_heading">
            <h3>about us
            </h3>
          </div>
          <div class="kf_inr_breadcrumb">
            <ul>
              <li>
                <a href="#">Home
                </a>
              </li>
              <li>
                <a href="#">about us
                </a>
              </li>
            </ul>
          </div>
        </div>
        <!--KF INR BANNER DES Wrap End-->
      </div>
    </div>
  </div>
</div>
<!--Banner Wrap End-->
<!--Content Wrap Start-->
<div class="kf_content_wrap">
  <!--ABOUT UNIVERSITY START-->
  <section>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="abt_univ_wrap">
            <!-- HEADING 1 START-->
            <div class="kf_edu2_heading1">
              <div class="row">
                <div class="col-md-12">
                  <h5>
                    <center>About Our JSS MAHAVIDYAPEETHA
                    </center>
                  </h5>
                  <p>
                    <center> J.S.S. MAHAVIDYAPEETHA , the educational wing of Sri Suttur Veerasimhasana Math was founded in 1954 by His Holiness Jagadguru Dr. Sri Shivarathri Rajendra Mahaswamigalavaru. As the foremost educational institution in Karnataka, JSS Mahavidyapeetha has been spearheading the cause of comprehensive education to the children of the States of Karnataka, Tamilnadu and Uttar Pradesh in India, Mauritius, Dubai & United States of America with about 300 educational institutions ranging from kindergarten to post-graduate, medical, engineering and management institutions. Over 35,000 students study in these institutions of which over 4000 reside in the free boarding homes of JSS Mahavidyapeetha.
                    </center>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section style="padding-top: 1px;">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="kf_edu2_heading1">
            <h3>Welcome To JSS MAHAVIDYAPEETHA
            </h3>
            <!-- HEADING 1 END-->
            <div class="row">
              <div class="col-md-12">
                <div class="abt_univ_des">
                  <p>Has established a separate directorate to look after its technical institutions. This directorate, under the control of Director (Technical), operates with an integrated approach to produce technical manpower. The polytechnics and Industrial Training Centres lay emphasis on skill development in the technical manpower where as the Colleges of Engineering lay emphasis on the transfer of technology, research and development, higher education in engineering, Consultancy, sponsored projects, continuing education, Industry - Institute partnership etc., Science and Technology Entrepreneurs Parks (STEPs) attached to engineering colleges address themselves to product development and entrepreneurship development.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        

          <div class="row">
            <div class="col-md-6">

                <figure>
                  <img src="<?php echo base_url();?>assets/images/about/maha.jpg" alt="" style="margin-top: 95px;"/>
                </figure>
              </div>
            </div> 
        </div>
      </div>
    </div>
</section>
</div>
</div>
</div>
</div>
</section>
<!--ABOUT UNIVERSITY END-->
<?php include('footer.php'); ?>