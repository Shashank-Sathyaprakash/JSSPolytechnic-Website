<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index()
	{
		$this->load->view('admin/dashboard');
	}
	public function slider()
	{
		$pagedata['slider']=$this->db->get('slider')->result_array();
		$this->load->view('admin/slider',$pagedata);
	}
	public function staff()
	{
		$pagedata['staff']=$this->db->get('staff')->result_array();
		$this->load->view('admin/staff',$pagedata);
	}
	public function facilities()
	{
		$pagedata['facilities']=$this->db->get('facilities')->result_array();
		$this->load->view('admin/facilities',$pagedata);
	}
	public function latestnews()
	{
		$pagedata['latestnews']=$this->db->get('latestnews')->result_array();
		$this->load->view('admin/latestnews',$pagedata);
	}
	public function Welcome()
	{
		$pagedata['welcome']=$this->db->get('welcome')->result_array();
		$this->load->view('admin/welcome',$pagedata);
	}
	public function testimonials()
	{
		$pagedata['testimonials']=$this->db->get('testimonials')->result_array();
		$this->load->view('admin/testimonials',$pagedata);
	}
	public function adddept()
	{
		$pagedata['adddept']=$this->db->get('adddept')->result_array();
		$this->load->view('admin/adddept',$pagedata);
	}	
	 public function deptdeatils()
    {
        $pagedata['deptdeatils']=$this->db->get('deptdeatils')->result_array();
        $this->load->view('admin/deptdeatils',$pagedata);
    }
       public function notes()
    {
        $pagedata['notes']=$this->db->get('notes')->result_array();
        $this->load->view('admin/notes',$pagedata);
    }
    
	public  function addSlider()
	{
		
		$data = array('text1' => $this->input->post('text1') ,
		       'text2' => $_POST['text2'], 
		        'text3' => $this->input->post('text3')
		    );
		$this->db->insert('slider',$data);
		redirect(base_url()."index.php/admin/slider");

	}
	public  function addstaff()
	{
		
		$data1 = array('Name' => $this->input->post('Name'),
			 'Staffinfo' => $this->input->post('Staffinfo')

		    );
		$this->db->insert('staff',$data1);
		redirect(base_url()."index.php/admin/staff");

	}
	public  function addfacilities()
	{
		
		$data2 = array('Text' => $this->input->post('Text')
           
            );
		$this->db->insert('facilities',$data2);
		redirect(base_url()."index.php/admin/facilities");

	}
	public  function addlatestnews()
	{
		
		$data3 = array('Date' => $this->input->post('Date'),
			'Text' => $this->input->post('Text'),
			'editor1' => $this->input->post('editor1')
           
            );
		$this->db->insert('latestnews',$data3);
		redirect(base_url()."index.php/admin/latestnews");

	}
	public  function addwelcome()
	{
		
		$data4 = array('editor1' => $this->input->post('editor1')
			
           
            );
		$this->db->insert('welcome',$data4);
		redirect(base_url()."index.php/admin/welcome");

	}
	public  function addtestimonials()
	{
		
		$data5 = array('Text' => $this->input->post('Text'),
			'editor1' => $this->input->post('editor1')
           
            );
		$this->db->insert('testimonials',$data5);
		redirect(base_url()."index.php/admin/testimonials");

	}
	public  function addadddept()
	{
		
		$data6 = array('Text' => $this->input->post('Text'),
			'Textarea' => $this->input->post('Textarea')
           
            );
		$this->db->insert('adddept',$data6);
		redirect(base_url()."index.php/admin/adddept");

	}
	public  function adddeptdeatils()
    {
        
        $data7 = array('Dept_name' => $this->input->post('Dept_name'),
            'editor1' => $this->input->post('editor1'),
            'from_HOD_desk' => $this->input->post('from_HOD_desk'),
            'testimonials' => $this->input->post('testimonials'),
           
            );
        $this->db->insert('deptdeatils',$data7);
        redirect(base_url()."index.php/admin/deptdeatils");

    }
    public function syllabus()
    {
    	$pagedata['syllabus']=$this->db->get('syllabus')->result_array();
    	$this->load->view('admin/syllabus',$pagedata);
    }

    public function addsyllabus()
	{
		$data_syllabus = array(
			'department' => $this->input->post('dept'),
			'url' => $this->input->post('url'));
		$this->db->insert('syllabus',$data_syllabus);
		redirect(base_url()."index.php/admin/syllabus");
	}

	public function addnotes()
	{
		$data_notes = array('semester' => $this->input->post('sem'),
			'department' => $this->input->post('dept'),
			'subject' => $this->input->post('sub'));
		$this->db->insert('notes',$data_notes);
		$id=$this->db->insert_id();
		

		$config['upload_path'] = 'uploads/notes/'.$this->input->post('dept').'/'.$this->input->post('sem').'/';
		$config['allowed_types'] = 'pdf';
		$config['file_name']=$id;
		echo $config['upload_path'];

		$this->load->library('upload',$config);

			
                if (! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        print_r($error);	
                        echo "file upload unsuccessful";
                        $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $this->db->set('file',$data["upload_data"]["file_name"]); 
                        $this->db->where('id',$id);
                        $this->db->update('notes');
                        echo "file upload successful" ;                    
                        $this->load->view('upload_success', $data);
                }		
                redirect(base_url()."index.php/admin/notes");

	}
	
	public function cet()
	{
		$this->load->view('admin/cet');
	}
	
	
	public function calendar_of_events()
	{
		$pagedata['calendar_of_events']=$this->db->get('calendar_of_events')->result_array();
		$this->load->view('admin/calendar_of_events');
	}
	
	public function time_table()
	{
		$pagedata['time_table']=$this->db->get('time_table')->result_array();
		$this->load->view('admin/time_table',$pagedata);
	}

  public function question_paper()
	{
		$pagedata['question_paper']=$this->db->get('question_paper')->result_array();
		$this->load->view('admin/question_paper',$pagedata);
	}

public function addquestion_paper()
	{
			$data_question_paper = array('semester' => $this->input->post('sem'),
			'department' => $this->input->post('dept'),
			'subject' => $this->input->post('sub'));
		    $this->db->insert('question_paper',$data_question_paper);
		    $id=$this->db->insert_id();

			$config['upload_path'] = 'uploads/question_paper/'.$this->input->post('dept').'/'.$this->input->post('sem').'/';
			$config['allowed_types'] = 'pdf';
			$config['file_name']=$id;
			echo $config['upload_path'];
			$this->load->library('upload', $config);

				
                if (! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        print_r($error);
                        echo "file upload unsuccessful";
                        $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());                      
                        echo "successful";
                        $this->db->set('file',$data["upload_data"]["file_name"]); 
                        $this->db->where('id',$id);
                        $this->db->update('question_paper');
                        echo "file upload successful" ;                    
                        $this->load->view('upload_success', $data);

                }
                redirect(base_url()."index.php/admin/question_paper");
	}

	public function addcalendar_of_events()
	{

		$id=$this->db->insert_id();
		$this->db->insert('calendar_of_events');
		$config['upload_path'] = 'uploads/calendar_of_events/';
		$config['allowed_types'] = 'pdf';
		$config['file_name']=$id;
		echo $config['upload_path'];

		$this->load->library('upload',$config);

				
                if (! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        print_r($error);	
                        echo "file upload unsuccessful";
                        $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                        $this->db->set('file',$data["upload_data"]["file_name"]); 
                        $this->db->where('id',$id);
                        $this->db->update('calendar_of_events');
                        echo "file upload successful" ;                    
                        $this->load->view('upload_success', $data);
                }		
                redirect(base_url()."index.php/admin/calendar_of_events");

	}


	public function addtime_table()
	{
		      
		$data_time_table= array('department' => $this->input->post('dept')
			);
		$this->db->insert('time_table',$data_time_table);
		$id=$this->db->insert_id();

		
			$config['upload_path'] = 'uploads/time_table/'.$this->input->post('dept').'/';
			echo $config['upload_path'];
			$config['allowed_types'] = 'pdf';

			$this->load->library('upload',$config);

				
                if (! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        echo "file upload unsuccessful";
                        $this->load->view('upload_form', $error);
                }
                else
                {
                		$data = array('upload_data' => $this->upload->data());
                        $this->db->set('file',$data["upload_data"]["file_name"]); 
                        $this->db->where('id',$id);
                        $this->db->update('time_table');
                        echo "file upload successful" ;                    
                        $this->load->view('upload_success', $data);

                       
                redirect(base_url()."index.php/admin/time_table");
	}
}
}
