<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class student_portal extends CI_Controller {

	public function index()
	{
		$this->load->view('student_portal/index');
	}
	public function calendar_of_events()
	{
		
		$data["calendar_of_events"]=$this->db->get("calendar_of_events")->result_array();
		$this->load->view('student_portal/calendar_of_events',$data);
	}
	public function time_table()
	{
		
		$data["time_table"]=$this->db->get("time_table")->result_array();
		$this->load->view('student_portal/time_table',$data);
	}
	public function syllabus()
	{
		$pagedata['syllabus']=$this->db->get('syllabus')->result_array();
		$this->load->view('student_portal/syllabus',$pagedata);
	}
	public function notes()
	{
		$this->db->where('department',"CS");
		$data["notes"]=$this->db->get("notes")->result_array();
		$this->load->view('student_portal/notes',$data);
	}
	public function question_paper()
	{
		$this->db->where('department',"CS");
		$data["question_paper"]=$this->db->get("question_paper")->result_array();
		$this->load->view('student_portal/question_paper',$data);
	}
	public function cet()
	{
		$this->load->view('student_portal/cet');
	}
	
}
